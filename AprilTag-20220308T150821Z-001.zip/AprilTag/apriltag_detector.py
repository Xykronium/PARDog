#!/usr/bin/python
# -*- coding: utf-8 -*-
## License: Apache 2.0. See LICENSE file in root directory.
## Copyright(c) 2019 Intel Corporation. All Rights Reserved.
# Python 2/3 compatibility
from __future__ import print_function

from numpy.ma import indices

"""
This example shows how to use T265 intrinsics and extrinsics in OpenCV to
asynchronously compute depth maps from T265 fisheye images on the host.

T265 is not a depth camera and the quality of passive-only depth options will
always be limited compared to (e.g.) the D4XX series cameras. However, T265 does
have two global shutter cameras in a stereo configuration, and in this example
we show how to set up OpenCV to undistort the images and compute stereo depth
from them.

Getting started with python3, OpenCV and T265 on Ubuntu 16.04:

First, set up the virtual enviroment:

$ apt-get install python3-venv  # install python3 built in venv support
$ python3 -m venv py3librs      # create a virtual environment in pylibrs
$ source py3librs/bin/activate  # activate the venv, do this from every terminal
$ pip install opencv-python     # install opencv 4.1 in the venv
$ pip install pyrealsense2      # install librealsense python bindings

Then, for every new terminal:

$ source py3librs/bin/activate  # Activate the virtual environment
$ python3 t265_stereo.py        # Run the example
"""

# First import the library
import pyrealsense2 as rs

# Import OpenCV and numpy
import cv2
import numpy as np
from math import tan, pi

# import pyAprilTag

import pupil_apriltags

from pupil_apriltags import Detector
from transforms3d.quaternions import mat2quat, quat2mat
from sklearn.cluster import DBSCAN
"""
In this section, we will set up the functions that will translate the camera
intrinsics and extrinsics from librealsense into parameters that can be used
with OpenCV.

The T265 uses very wide angle lenses, so the distortion is modeled using a four
parameter distortion model known as Kanalla-Brandt. OpenCV supports this
distortion model in their "fisheye" module, more details can be found here:

https://docs.opencv.org/3.4/db/d58/group__calib3d__fisheye.html
"""

"""
Returns R, T transform from src to dst
"""


def get_extrinsics(src, dst):
    extrinsics = src.get_extrinsics_to(dst)
    R = np.reshape(extrinsics.rotation, [3, 3]).T
    T = np.array(extrinsics.translation)
    return (R, T)


"""
Returns a camera matrix K from librealsense intrinsics
"""


def camera_matrix(intrinsics):
    return np.array([[intrinsics.fx, 0, intrinsics.ppx],
                     [0, intrinsics.fy, intrinsics.ppy],
                     [0, 0, 1]])


"""
Returns the fisheye distortion from librealsense intrinsics
"""


def fisheye_distortion(intrinsics):
    return np.array(intrinsics.coeffs[:4])


# Set up a mutex to share data between threads
from threading import Lock

frame_mutex = Lock()
frame_data = {"left": None,
              "right": None,
              "timestamp_ms": None
              }

"""
This callback is called on a separate thread, so we must use a mutex
to ensure that data is synchronized properly. We should also be
careful not to do much work on this thread to avoid data backing up in the
callback queue.
"""


def callback(frame):
    global frame_data
    if frame.is_frameset():
        frameset = frame.as_frameset()
        f1 = frameset.get_fisheye_frame(1).as_video_frame()
        f2 = frameset.get_fisheye_frame(2).as_video_frame()
        left_data = np.asanyarray(f1.get_data())
        right_data = np.asanyarray(f2.get_data())
        ts = frameset.get_timestamp()
        frame_mutex.acquire()
        frame_data["left"] = left_data
        frame_data["right"] = right_data
        frame_data["timestamp_ms"] = ts
        frame_mutex.release()


at_detector = Detector(families='tag36h11',
                       nthreads=1,
                       quad_decimate=1.0,
                       quad_sigma=0.0,
                       refine_edges=1,
                       decode_sharpening=0.25,
                       debug=0)

# Declare RealSense pipeline, encapsulating the actual device and sensors
pipe = rs.pipeline()

# Build config object and stream everything
cfg = rs.config()

def get_apriltag(cfg):
    # Start streaming with our callback
    pipe.start(cfg, callback)
    try:
        # Set up an OpenCV window to visualize the results
        #WINDOW_TITLE = 'Realsense'
        #cv2.namedWindow(WINDOW_TITLE, cv2.WINDOW_NORMAL)

        # Configure the OpenCV stereo algorithm. See
        # https://docs.opencv.org/3.4/d2/d85/classcv_1_1StereoSGBM.html for a
        # description of the parameters
        window_size = 5
        min_disp = 0
        # must be divisible by 16
        num_disp = 112 - min_disp
        max_disp = min_disp + num_disp

        # Retreive the stream and intrinsic properties for both cameras
        profiles = pipe.get_active_profile()
        streams = {"left": profiles.get_stream(rs.stream.fisheye, 1).as_video_stream_profile(),
                   "right": profiles.get_stream(rs.stream.fisheye, 2).as_video_stream_profile()}
        intrinsics = {"left": streams["left"].get_intrinsics(),
                      "right": streams["right"].get_intrinsics()}

        # Print information about both cameras
        print("Left camera:", intrinsics["left"])
        print("Right camera:", intrinsics["right"])

        # Translate the intrinsics from librealsense into OpenCV
        K_left = camera_matrix(intrinsics["left"])
        D_left = fisheye_distortion(intrinsics["left"])
        K_right = camera_matrix(intrinsics["right"])
        D_right = fisheye_distortion(intrinsics["right"])
        (width, height) = (intrinsics["left"].width, intrinsics["left"].height)

        # Get the relative extrinsics between the left and right camera
        (R, T) = get_extrinsics(streams["left"], streams["right"])

        # We need to determine what focal length our undistorted images should have
        # in order to set up the camera matrices for initUndistortRectifyMap.  We
        # could use stereoRectify, but here we show how to derive these projection
        # matrices from the calibration and a desired height and field of view

        # We calculate the undistorted focal length:
        #
        #         h
        # -----------------
        #  \      |      /
        #    \    | f  /
        #     \   |   /
        #      \ fov /
        #        \|/
        stereo_fov_rad = 90 * (pi / 180)  # 90 degree desired fov
        stereo_height_px = 575  # 300x300 pixel stereo output
        stereo_focal_px = stereo_height_px / 2 / tan(stereo_fov_rad / 2)

        # We set the left rotation to identity and the right rotation
        # the rotation between the cameras
        R_left = np.eye(3)
        R_right = R

        # The stereo algorithm needs max_disp extra pixels in order to produce valid
        # disparity on the desired output region. This changes the width, but the
        # center of projection should be on the center of the cropped image
        stereo_width_px = stereo_height_px + max_disp
        stereo_size = (stereo_width_px, stereo_height_px)
        stereo_cx = (stereo_height_px - 1) / 2 + max_disp
        stereo_cy = (stereo_height_px - 1) / 2

        # Construct the left and right projection matrices, the only difference is
        # that the right projection matrix should have a shift along the x axis of
        # baseline*focal_length
        P_left = np.array([[stereo_focal_px, 0, stereo_cx, 0],
                           [0, stereo_focal_px, stereo_cy, 0],
                           [0, 0, 1, 0]])
        P_right = P_left.copy()
        P_right[0][3] = T[0] * stereo_focal_px

        # Construct Q for use with cv2.reprojectImageTo3D. Subtract max_disp from x
        # since we will crop the disparity later
        Q = np.array([[1, 0, 0, -(stereo_cx - max_disp)],
                      [0, 1, 0, -stereo_cy],
                      [0, 0, 0, stereo_focal_px],
                      [0, 0, -1 / T[0], 0]])

        # Create an undistortion map for the left and right camera which applies the
        # rectification and undoes the camera distortion. This only has to be done
        # once

        # new_K_left, roi = cv2.getOptimalNewCameraMatrix(K_left, D_left, (800,848), 1, (800,848))
        # print("new_K_left:")
        # print(new_K_left)

        m1type = cv2.CV_32FC1
        (lm1, lm2) = cv2.fisheye.initUndistortRectifyMap(K_left, D_left, R_left, P_left, stereo_size, m1type)
        (rm1, rm2) = cv2.fisheye.initUndistortRectifyMap(K_right, D_right, R_right, P_right, stereo_size, m1type)
        undistort_rectify = {"left": (lm1, lm2),
                             "right": (rm1, rm2)}

        nFrame = 0

        #Can this be set while running to terminate?
        continue_search = True

        stored_translation = []
        stored_rotation = []

        while continue_search:
            # Check if the camera has acquired any frames
            frame_mutex.acquire()
            valid = frame_data["timestamp_ms"] is not None
            frame_mutex.release()

            # If frames are ready to process
            if valid:
                # Hold the mutex only long enough to copy the stereo frames
                frame_mutex.acquire()
                frame_copy = {"left": frame_data["left"].copy(),
                              "right": frame_data["right"].copy()}
                frame_mutex.release()

                # Undistort and crop the center of the frames
                center_undistorted = {"left": cv2.remap(src=frame_copy["left"],
                                                        map1=undistort_rectify["left"][0],
                                                        map2=undistort_rectify["left"][1],
                                                        interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT),
                                      "right": cv2.remap(src=frame_copy["right"],
                                                         map1=undistort_rectify["right"][0],
                                                         map2=undistort_rectify["right"][1],
                                                         interpolation=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT)}

                # compute the disparity on the center of the frames and convert it to a pixel disparity (divide by DISP_SCALE=16)
                #disparity = stereo.compute(center_undistorted["left"], center_undistorted["right"]).astype(np.float32) / 16.0

                #############################################################################
                # re-crop just the valid part of the disparity
                # disparity = disparity[:, max_disp:]
                # print(disparity)
                ##############################################################################

                # left camera
                color_image = cv2.cvtColor(center_undistorted["left"][:, max_disp:], cv2.COLOR_GRAY2RGB)
                # ids, corners, centers, Hs = pyAprilTag.find(color_image)

                # # left camera
                color_image_fish = cv2.cvtColor(frame_copy["left"][:, max_disp:], cv2.COLOR_GRAY2RGB)

                #undist_left = cv2.undistort(color_image_fish, K_left, D_left, new_K_left)

                # right camera
                color_image2 = cv2.cvtColor(center_undistorted["right"][:, max_disp:], cv2.COLOR_GRAY2RGB)
                # ids, corners, centers, Hs = pyAprilTag.find(color_image2)

                # cv2.imshow(WINDOW_TITLE, color_image2)
                # Showing feed from both cameras
                #cv2.imshow(WINDOW_TITLE, undist_left)
                #cv2.imshow(WINDOW_TITLE, np.hstack((color_image, color_image2)))

                # left camera grey frame
                gframeL = cv2.cvtColor(color_image, cv2.COLOR_BGR2GRAY)

                gfishL = cv2.cvtColor(color_image_fish, cv2.COLOR_BGR2GRAY)
                # cv2.imshow(WINDOW_TITLE, color_image)
                # # right camera grey frame

                # right camera grey frame
                gframeR = cv2.cvtColor(color_image2, cv2.COLOR_BGR2GRAY)

                #######
                # print every second if fps = 25
                if nFrame % 25 == 0:
                    # Using the left camera to get distances
                    fx = K_left[0, 0]
                    fy = K_left[1, 1]
                    cx = K_left[0, 2]
                    cy = K_left[1, 2]
                    tags = at_detector.detect(gframeL, estimate_tag_pose=True, camera_params=[fx, fy, cx, cy],
                                              tag_size=0.17272)
                    # print(tags)
                    if tags != []:
                        stored_translation.append(tags[0].pose_t) # possible .astype(object) if making numpy array
                        stored_rotation.append(tags[0].pose_R)
                        translation = tags[0].pose_t
                        rotation = tags[0].pose_R
                        invTrans = -np.linalg.inv(rotation).dot(translation)
                        print("Distance to apriltag invTrans[2] = ", invTrans[2])
                        # print("Distance to apriltag invTrans[1] = ", invTrans[1])
                        # print("Distance to apriltag invTrans[0] = ", invTrans[0])
                        # print("Distance to apriltag invTrans = ", invTrans)
                        # print("Distance to apriltag = ", np.linalg.norm(invTrans))
                        # print("Distance to apriltag = ", np.linalg.norm(translation))
                        # print(rotation)

                nFrame += 1

            key = cv2.waitKey(1)

            # print("Last Stored Rotation:")
            # print(stored_rotation[-1:])
            # print("Last Stored Translation:")
            # print(stored_translation[-1:])
            # print("Last Stored Rotation"+ stored_rotation[-1:])
            # print("Last Stored Translation" + stored_translation[-1:])
            # Make Consistency Check a function
            if len(stored_rotation)>9:
                # DBSCAN with euclidean translation vector then with mat2quat() rotation vector
                #indx_stored_rotation = np.array(stored_rotation)
                #print(indx_stored_rotation[-1:])

                # Format Rotation Matrix for DBScan
                for mat in range(len(stored_rotation)):
                    stored_rotation[mat] = mat2quat(stored_rotation[mat])


                # print("Last Stored Rotation Matrix in its Quaternion Form:")
                # print(stored_rotation[-1:])
                # print("Stored Rotation array dim:")
                # print(np.shape(stored_rotation))

                # Format Translation Vector for DBScan
                stored_translation = np.reshape(stored_translation, (10,3))
                # print("Reshaped translation:")
                # print(stored_translation)

                #print(indx_stored_rotation[-1:])
                # rot_quat = mat2quat(stored_rotation[-10:])
                rot_check = DBSCAN(eps=0.5, min_samples=8).fit(np.array(stored_rotation))
                # print("rot_check:")
                # print(rot_check.labels_)

                trans_check = DBSCAN(eps=0.1, min_samples=8).fit(np.array(stored_translation))
                # print("trans_check:")
                # print(trans_check.labels_)

                if np.logical_and(not np.any(rot_check.labels_), not np.any(trans_check.labels_)):
                #if np.logical_and(-1 not in rot_check.labels_, -1 not in trans_check.labels_).any():
                    print("Recording Stable Rotation and Translation values")
                    rot = quat2mat(np.reshape(stored_rotation[-1:], (4,1)))
                    trans = np.reshape(stored_translation[-1:], (1,3))[0]

                    # could reset stored values here, but might want to check for accuracy
                    continue_search = False
                else:
                    stored_rotation = []
                    stored_translation = []

    finally:
        pipe.stop()
    return rot,trans