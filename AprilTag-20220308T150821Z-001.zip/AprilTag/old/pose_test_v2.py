import e_apriltag_v2

# First import the library
import pyrealsense2 as rs

# Declare RealSense pipeline, encapsulating the actual device and sensors
pipe = rs.pipeline()

# Build config object and stream everything
cfg = rs.config()

rotation, translation = e_apriltag_v2.get_apriltag(cfg)

print("Rotation Matrix:")
print(rotation)
print("Translation Vector:")
print(translation)
