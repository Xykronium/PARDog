import os
import sys
import numpy as np
import cv2
from transforms3d.euler import euler2mat, mat2euler, quat2euler
from transforms3d.quaternions import quat2mat, mat2quat
from transforms3d.quaternions import qinverse
from transforms3d.quaternions import qconjugate
from transforms3d.quaternions import qmult
import math
import pyrealsense2 as rs
import random
from math import asin
from math import acos
from math import degrees
from math import radians

import apriltag_detector

'''

ALGORITHM IDEAS

Using the K[R|t], we can figure out where the images should appear on a 2d image plane

Then we can find the homography between the opencv images after they have been scaled down and translated to the centroid and the images as they should appear on a projection plane

The points of the opencv images are the point locations after they have been transformed down

The points of the 

'''


### PyRealSense Stuff goes here:
pipe = rs.pipeline()
cfg = rs.config()
cfg.enable_stream(rs.stream.pose)
pipe.start(cfg)
###End of PyRealSense Stuff

class AprilTag:
    def __init__(self, translation, rotation):
        self.translation = translation
        self.rotation = self._make_quat(rotation)
    
    def _make_quat(self,rotation):
        return mat2quat(rotation)

class Camera:
    def  __init__(self,position=np.array([0.,0.,0.]),orientation=np.array([1.,0.,0.,0.]),K=np.eye(3,dtype='float64'),dist_coeffs = np.array([0.0,0.0])):
        self.intrinsics = self.Intrinsics(K,dist_coeffs)
        self.extrinsics = self.Extrinsics(position,orientation)
        
    class Intrinsics:
        def __init__(self,K,dist_coeffs):
            self.K = K
            self.dist_coeffs = dist_coeffs
    
    class Extrinsics:
        def __init__(self,position,orientation):
            self._projector_position = position
            self._projector_orientation_quat = orientation
            self._projector_orientation_mat = self.calculate_R_mat()
            self.R = self._get_R(self._projector_orientation_mat)
            self.C = self._get_C(self._projector_position)
            self.RT_mat = self.calculate_RT_mat()

        def calculate_R_mat(self):
            return quat2mat(self._projector_orientation_quat)

        def _get_C(self,position):
            x = position[0]
            y = position[1]
            z = position[2]
            C = np.array([[1.,0.,0.,-x],
                          [0.,1.,0.,-y],
                          [0.,0.,1.,-z],
                          [0.,0.,0.,1.]])
            return C

        def _get_R(self,r_mat):
            r11 = r_mat[0][0]
            r12 = r_mat[0][1]
            r13 = r_mat[0][2]
            r21 = r_mat[1][0]
            r22 = r_mat[1][1]
            r23 = r_mat[1][2]
            r31 = r_mat[2][0]
            r32 = r_mat[2][1]
            r33 = r_mat[2][2]

            R = np.array([[r11,r12,r13,0.],
                          [r21,r22,r23,0.],
                          [r31,r32,r33,0.],
                          [0. ,0. ,0. ,1.]])
            return R

        def calculate_RT_mat(self):
            self.R = self._get_R(self._projector_orientation_mat)
            self.C = self._get_C(self._projector_position)
            return np.matmul(self.R,self.C)[:-1,:]
            # return np.column_stack((self._projector_orientation_mat,self._projector_position))

    
class ProjectedImages:
    def __init__(self,apriltag_translation,apriltag_orientation,position,size,orientation,file_name):
        '''GENERAL THINGS'''
        self.file_name = file_name
        self.image = self.get_picture()
        self.orientation = orientation
        self.calculate_homography = True
        self.final_homography = None
        self.warped_image = None
        self.T_matrix_prime = self._T_matrix_prime()
        self.T_matrix_prime_inverse = np.linalg.inv(self.T_matrix_prime)
        '''APRILTAG POINTS'''
        self.apriltag_translation = apriltag_translation
        self.apriltag_orientation = quat2mat(apriltag_orientation)
        self.initial_image_orientation = euler2mat(0, radians(orientation), 0)  # Tells us how to rotate
        self.position = position  # Tells us where the center is
        self.size = size  # Tells us how big it is
        self._euclidean_coordinates_apriltag_coordinate_system = self._get_euclidean_world_coordinates(size, position)
        self._homogeneous_coordinates_apriltag_coordinate_system = self.make_homogeneous(self._euclidean_coordinates_apriltag_coordinate_system)
        self.world_epsilon_apriltag = self._transform_apriltag_to_world(self.apriltag_translation,self.apriltag_orientation)
        '''WORLD POINTS'''
        # self._euclidean_world_coordinates = self._get_euclidean_world_coordinates(size,position) #We calculate this to figure out where the corners should be in euclidean 3-space

        self._homogeneous_world_coordinates = self._get_homogeneous_world_coordinates_from_homogeneous_apriltag_coordinates(self.world_epsilon_apriltag,self._homogeneous_coordinates_apriltag_coordinate_system)
        #self._homogeneous_coordinates_apriltag_coordinate_system #This is based on the self._euclidean_world_coordinates, simply make these coordinates homogenous

        self._homogeneous_image_plane_coordinates = None #This is the self._homogeneous_world_coordinates projected onto the 2D image plane
        self._euclidean_image_plane_coordinates = None #self.make_euclidean(self._homogeneous_image_plane_coordinates)
        self._T_matrix = None #This is the matrix to normalize the homogeneous coordinates
        self._normalized_homogeneous_image_plane_coordinates = None #This is the normalized self._homogeneous_image_plane_coordinates
        self._normalized_euclidean_image_plane_coordinates = None #This is based on the self._normalized_homogeneous_image_plane_coordinates, simply make these coordinates euclidean
        self._T_matrix_inverse = None #This is needed to calculate the correct homography
        '''IMAGE POINTS'''
        self.euclidean_corner_locations = self._get_euclidean_corner_locations(self.image) #This tells us where the corner locations are for an opencv image
        self.homogeneous_corner_locations = self.make_homogeneous(self.euclidean_corner_locations) #This is based on the self.corner_locations, simple make these coordinates homogeneous
        self.T_matrix = self.calculate_T_matrix(self.euclidean_corner_locations) #This is the matrix to normalize the homogeneous coordinates
        self.normalized_homogeneous_corner_locations = np.matmul(self.T_matrix,self.homogeneous_corner_locations) #This is the normalized self.homogeneous_corner_locations
        self.normalized_euclidean_corner_locations = self.make_euclidean(self.normalized_homogeneous_corner_locations) #This is based on the self.normalized_homogeneous_corner_locations, simply make these coordinates euclidean
        self.T_matrix_inverse = np.linalg.inv(self.T_matrix) #This is needed to calculate the correct homography
        
    '''GENERAL THINGS'''
    ###This function may be deleted
    def add_apriltag_translation_distance(self,initial_translation, position):
        #This function will account for the initial translation distance of the robot from the AprilTag initializer
        holder = np.array([initial_translation[0]+position[0],
                           initial_translation[1]+position[1],
                           initial_translation[2]-position[2]])
        return holder
    ###The above function may be deleted

    def get_picture(self):
        #This function creates an openCV video stream object that we can display.
        #This is how we will manipulate the images
        frame = cv2.imread(self.file_name)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        return gray
    
    def make_homogeneous(self,euclidean_vector):
        #This function will make a euclidean n-space vector a homogeneous n-space vector
        #Inputs must be inputted such that each coloumn represents a euclidean vector
        '''
        2-space example input
        vec = [[x1, x2, x3, x4, ... xn],
               [y1, y2. y3, y4, ... yn]]

        3-space example input
        vec = [[x1, x2, x3, x4, ... xn],
               [y1, y2. y3, y4, ... yn],
               [z1, z2, z3, z4, ... zn]]
        '''
        ones_vector = np.ones(euclidean_vector.transpose().shape[0])
        return (np.column_stack((euclidean_vector.transpose(),ones_vector))).transpose()

    def make_euclidean(self,homogeneous_vectors):
        #This function will make a homogeneous n-space vector a euclidean n-space vector
        #Inputs must be inputted such that each coloumn represents a homogeneous vector
        '''
        2-space example input
        vec = [[x1, x2, x3, x4, ... xn],
               [y1, y2. y3, y4, ... yn],
               [1., 1., 1., 1., ... 1.]]

        3-space example input
        vec = [[x1, x2, x3, x4, ... xn],
               [y1, y2. y3, y4, ... yn],
               [z1, z2, z3, z4, ... zn],
               [1., 1., 1., 1., ... 1.]]
        '''
        return (self.perspective_division(homogeneous_vectors))[:-1,:]
        # return homogeneous_vectors[:-1,:]

    def perspective_division(self,homogeneous_vector):
        #This function will take a homogeneous n-space vector and divide every vector component by the homogeneous w component/final number
        #Inputs must be inputted such that each coloumn represents a homogeneous vector
        '''
        2-space example input
        vec = [[x1, x2, x3, x4, ... xn],
               [y1, y2. y3, y4, ... yn],
               [1., 1., 1., 1., ... 1.]]

        3-space example input
        vec = [[x1, x2, x3, x4, ... xn],
               [y1, y2. y3, y4, ... yn],
               [z1, z2, z3, z4, ... zn],
               [1., 1., 1., 1., ... 1.]]
        '''
        w_components = homogeneous_vector[-1:,:]
        return (homogeneous_vector.transpose() / w_components.reshape(-1,1)).transpose()

    def calculate_T_matrix(self,euclidean_2_space_points):
        #This function takes in Euclidean 2 space points and finds the matrix required to normalize them
        required_tranlation_distance = self._calculate_image_centroid_location(euclidean_2_space_points)
        centered_image_points = self._center_points_around_origin(euclidean_2_space_points, required_tranlation_distance)
        scale_factor = self._find_average_distance_from_centroid(centered_image_points)
        S_down_mat = np.eye(3, dtype='float64')
        S_down_mat[0, 0] = (math.sqrt(2) / (scale_factor))
        S_down_mat[1, 1] = (math.sqrt(2) / (scale_factor))

        T_cent_mat = np.eye(3, dtype=int)
        T_cent_mat[0, 2] = -(required_tranlation_distance[0] / 2)
        T_cent_mat[1, 2] = -(required_tranlation_distance[1] / 2)

        return np.matmul(S_down_mat,T_cent_mat)

    def calculate_3space_T_matrix(self,euclidean_3_space_points,scaling = False):
        required_tranlation_distance = self._calculate_image_centroid_location(euclidean_3_space_points)
        print("\nrequired_tranlation_distance")
        print(required_tranlation_distance)
        # print(required_tranlation_distance[0][0])
        # print(required_tranlation_distance[1])
        # print(required_tranlation_distance[2])
        centered_image_points = self._center_points_around_origin(euclidean_3_space_points, required_tranlation_distance)
        
        S_down_mat = np.eye(4, dtype='float64')
        if scaling:
            scale_factor = self._find_average_distance_from_centroid(centered_image_points)
            S_down_mat[0, 0] = (math.sqrt(2) / (scale_factor))
            S_down_mat[1, 1] = (math.sqrt(2) / (scale_factor))
            S_down_mat[2, 2] = (math.sqrt(2) / (scale_factor))

        T_cent_mat = np.eye(4, dtype="float64")
        ##### WHY DO I DIVIDE BY 2 HERE???????????
        T_cent_mat[0, 3] = -(required_tranlation_distance[0])
        T_cent_mat[1, 3] = -(required_tranlation_distance[1])
        T_cent_mat[2, 3] = -(required_tranlation_distance[2])

        print("\nT_cent_mat")
        print(T_cent_mat)
        return np.matmul(S_down_mat,T_cent_mat)
        
    def _calculate_image_centroid_location(self,image_points):
        #This function will calculate the centroid of a series of points that are assumed to be representative of the image being manipulated
        #Inputs must be inputted such that each coloumn represents a euclidean vector
        '''
        2-space example input
        vec = [[x1, x2, x3, x4, ... xn],
               [y1, y2. y3, y4, ... yn]]

        3-space example input
        vec = [[x1, x2, x3, x4, ... xn],
               [y1, y2. y3, y4, ... yn],
               [z1, z2, z3, z4, ... zn]]
        ''' 
        x_ave_y_ave = image_points.sum(axis=1)
        return (x_ave_y_ave/4).reshape(-1,1)

    def _center_points_around_origin(self, original_points,original_points_centroid_dist_to_origin):
        #This function will calculate the distance an image must be translated to reach the origin
        #Inputs must be inputted such that each coloumn represents a euclidean vector
        '''
        2-space example input
        vec = [[x1, x2, x3, x4, ... xn],
               [y1, y2. y3, y4, ... yn]]

        3-space example input
        vec = [[x1, x2, x3, x4, ... xn],
               [y1, y2. y3, y4, ... yn],
               [z1, z2, z3, z4, ... zn]]
        ''' 
        return original_points - original_points_centroid_dist_to_origin
    
    def _find_average_distance_from_centroid(self,centered_original_points):
        #This function will calculate the average distance from the centroid that the representative points exist at
        #This will help calculate the scale up/scale down normalization matrix
        distances_to_centroid = np.linalg.norm(centered_original_points.transpose(),axis =1)
        summed_distances_of_points_to_centroid = distances_to_centroid.sum(axis=0)
        return summed_distances_of_points_to_centroid/4
    
    def _get_homography(self):
        pts_src = self.normalized_euclidean_corner_locations
        pts_dst = self._normalized_euclidean_image_plane_coordinates
        homography = cv2.findHomography(pts_src.transpose(),pts_dst.transpose())
        return homography

    def _get_final_homography(self):
        homography, mask = self._get_homography()
        # print("--")
        # print(homography)
        # print("-")
        # print(self.T_matrix)
        step1 = np.matmul(homography,self.T_matrix)
        step2 = np.matmul(self._T_matrix_inverse,step1)
        step3 = np.matmul(self.T_matrix_prime_inverse,step2)
        self.final_homography = step3

    def get_warped_image(self):
        self._get_final_homography()
        self.warped_image = cv2.warpPerspective(pic.image, pic.final_homography, (640, 480))
    
    def _T_matrix_prime(self, scale_factor = 1,final_width = 640,final_height = 480):
        ##Then we scale back up, we scale up by the same amount we scaled down
        ave_dist_to_final_centroid = math.sqrt((final_width/2)**2+(final_height/2)**2)
        S_up_mat = np.eye(3, dtype=float)
        
        S_up_mat[0, 0] = (math.sqrt(2) / (ave_dist_to_final_centroid))*scale_factor
        S_up_mat[1, 1] = (math.sqrt(2) / (ave_dist_to_final_centroid))*scale_factor

        ##Then we need the move the transformation back to the center of the screen
        T_cent_mat_final = np.eye(3, dtype=int)
        T_cent_mat_final[0, 2] = -(final_height / 2)
        T_cent_mat_final[1, 2] = -(final_width / 2)


        T_matrix_prime = np.matmul(S_up_mat,T_cent_mat_final)

        return T_matrix_prime

    '''APRILTAG POINTS'''
    def _transform_apriltag_to_world(self,translation,rot):

        rotation = rot
        # rotation = np.linalg.inv(rot)
        # print(rot)
        print(mat2euler(rot))
        t_x = translation[0]
        t_y = translation[1]
        t_z = translation[2]

        r11 = rotation[0][0]
        r12 = rotation[0][1]
        r13 = rotation[0][2]
        r21 = rotation[1][0]
        r22 = rotation[1][1]
        r23 = rotation[1][2]
        r31 = rotation[2][0]
        r32 = rotation[2][1]
        r33 = rotation[2][2]

        world_epsilon_apriltag = np.array([[r11, r12, r13, -t_x],
                                           [r21, r22, r23, -t_y],
                                           [r31, r32, r33, -t_z],
                                           [  0., 0., 0.,   1.]])

        at_trans_mat = np.array([[1., 0., 0., -t_x],
                                 [0., 1., 0., -t_y],
                                 [0., 0., 1., -t_z],
                                 [0., 0., 0.,  1.]])

        at_rot_mat = np.array([[r11, r12, r13, 0.],
                               [r21, r22, r23, 0.],
                               [r31, r32, r33, 0.],
                               [ 0.,  0.,  0., 1.]])

        # world_epsilon_apriltag=np.matmul(at_rot_mat,at_trans_mat)

        return np.linalg.inv( world_epsilon_apriltag )

    def _get_homogeneous_world_coordinates_from_homogeneous_apriltag_coordinates(self,transform,homogeneous_apriltag_coordinates):
        homogeneous_world_coordinates = np.matmul(transform,homogeneous_apriltag_coordinates)
        return homogeneous_world_coordinates
    '''WORLD POINTS'''
    def _get_euclidean_world_coordinates(self,size,center_position = np.array([0.0,0.0,0.0])):
        '''
        This function needs to be able to rotate an image in 3D space to the correct orientation
        This function should also be able to produce a non-square image and it should be based on the aspect ratio of the image as it is currently
        This function should also be able to produce an image with a specific size
        '''
        #size is in meters
        #center_position has x,y,z
        '''TRY THIS'''
        print("\n=====================================================================")
        print("\nvvv--",self.file_name,"--vvv")
        euclidean_3_space_world_coordinates = self._produce_unrotated_euclidean_world_coordinates(self.image,center_position,size)
        rotated_euclidean_3_space_world_coordinates = self._perform_3D_rotation(euclidean_3_space_world_coordinates,self.initial_image_orientation)
        print("^^^--",self.file_name,"--^^^")
        return rotated_euclidean_3_space_world_coordinates

        '''OR TRY THIS'''
        # _dist = size/2
        # _xi = center_position[0]
        # _yi = center_position[1]
        # _zi = center_position[2]
        # top_left = np.array([-_dist+_xi,_dist+_yi,0.0+_zi])
        # top_right = np.array([_dist+_xi,_dist+_yi,0.0+_zi])
        # bottom_left = np.array([-_dist+_xi,-_dist+_yi,0.0+_zi])
        # bottom_right = np.array([_dist+_xi,-_dist+_yi,0.0+_zi])
        # print("\nvvv--",self.file_name,"--vvv")
        # print("\nunrotated_euclidean_3_space_world_coordinates")
        # print(np.array([top_left,top_right,bottom_right,bottom_left]).transpose())
        # print("^^^--",self.file_name,"--^^^")
        # return np.array([top_left,top_right,bottom_right,bottom_left]).transpose()
        
    def _perform_3D_rotation(self,euclidean_3_space_world_coordinates,initial_image_orientation):
        '''
        This function will rotate an image to be at the correct orientation
        
        1 - In order to perform 3D rotations, we first need to get the 3-space euclidean points of the object being rotated
        2 - Then we need to find the matrix to normalize the 3-space euclidean points, ie. get them to the origin.
            Although this normally consists of a translation followed by a scaling, since we are only doing a rotation, we do not need to perform the scaling
        3 - Then after we have the normalization matrix, we need to convert the euclidean 3-space coordinates to homogeneous 3-space coordinates
        4 - Normalize homogeneous coordinates
        5 - Then after we have normalized 3-space homogeneous coordinates, we need to create the rotation that will achieve the desired 3D rotation
            This should be a 4 x 4 matrix
            It will be created by getting a 3 x 3 rotation matrix and inputting it's values into a 4 x 4 identity matrix
        6 - Then we need to perform a matrix operation with the homogeneous coordinates and the 4 x 4 rotation matrix to get the new homogeneous coordinates
        7 - Then we need to de-normalize with the inverse of the normalization matrix
        8 - Then we need to make the new homogeneous coordinates euclidean
        9 - The return value should be the denormalized euclidean 3-space coordinates
        '''
        #Step 1 - Get the euclidean 3-space coordinates
        # euclidean_3_space_world_coordinates
        
        #Step 2 - Get the normalization matrix
        Norm_mat = self.calculate_3space_T_matrix(euclidean_3_space_world_coordinates)

        #Step 3 - Convert 3-space euclidean coordinates to 3-space homogeneous coordinates 
        homogeneous_3_space_world_coordinates = self.make_homogeneous(euclidean_3_space_world_coordinates)

        #Step 4 - Normalize 3-space homogeneous coordinates 
        normalized_homogeneous_3_space_world_coordinates = np.matmul(Norm_mat,homogeneous_3_space_world_coordinates)

        #Step 5 - Create rotation to manipulate the homogeneous 3-space coordinates
        r_mat = initial_image_orientation
        r11 = r_mat[0][0]
        r12 = r_mat[0][1]
        r13 = r_mat[0][2]
        r21 = r_mat[1][0]
        r22 = r_mat[1][1]
        r23 = r_mat[1][2]
        r31 = r_mat[2][0]
        r32 = r_mat[2][1]
        r33 = r_mat[2][2]

        R = np.array([[r11,r12,r13,0.],
                        [r21,r22,r23,0.],
                        [r31,r32,r33,0.],
                        [0. ,0. ,0. ,1.]])
    
        #Step 6 - Rotate homogeneous coordinates
        rotated_normalized_homogeneous_3_space_world_coordinates = np.matmul(R,normalized_homogeneous_3_space_world_coordinates)

        #Step 7 - Denormalize rotated homogeneous coordinates
        Norm_mat_inv = np.linalg.inv(Norm_mat)
        rotated_homogeneous_3_space_world_coordinates = np.matmul(Norm_mat_inv,rotated_normalized_homogeneous_3_space_world_coordinates)

        #Step 8 - Make rotated homogeneous coordinates euclidean
        rotated_euclidean_3_space_world_coordinates = self.make_euclidean(rotated_homogeneous_3_space_world_coordinates)

        #Step 9 - Return denormalized rotated euclidean 3-space coordinates
        return rotated_euclidean_3_space_world_coordinates

    def _produce_unrotated_euclidean_world_coordinates(self,image,position,scale_factor = 1):
        '''
        This function will take in the image and get it's aspect ratio and produce a set of 3D euclidean coordinates.
        The image will be assumed to not be rotated and so this assumes that the image is the XY plane.
        In order to produce a set of unrotated euclidean world coordinates, we need to know:
            - The location of the image centroid
                - This is obtained from self.position
            - The image dimensions
                - This is obtained from self.image
        1 - Get the width and height of the image
        2 - Create values for half the width and height of the image
        3 - Create 4 points that are all located at the centroid of the image
        4 - Using the 4 points, do the following:
            A - point.x - width/2, point.y + height/2 <-- Top_left
            B - point.x + width/2, point.y + height/2 <-- Top_right
            C - point.x - width/2, point.y - height/2 <-- Bot_left
            D - point.x + width/2, point.y - height/2 <-- Bot_right
        5 - Return the Unrotated 3-space euclidean coordinates
        '''

        #Step 1 - Get the width and height of the image
        width = image.shape[1]
        height = image.shape[0]

        #Step 2 - Get values for half width and half height
        x_val = scale_factor * width/(2 * width)
        y_val = scale_factor * height/(2 * width)

        #Step 3 - Create 4 points that are all located at the centroid of the image
        _unrotated_3_space_coordinates = np.array([[position[0],position[1],position[2]],
                                                   [position[0],position[1],position[2]],
                                                   [position[0],position[1],position[2]],
                                                   [position[0],position[1],position[2]]])

        #Step 4 - Create unrotated world points locations
        _unrotated_3_space_coordinates[0][0] -= x_val
        _unrotated_3_space_coordinates[0][1] += y_val

        _unrotated_3_space_coordinates[1][0] += x_val
        _unrotated_3_space_coordinates[1][1] += y_val

        _unrotated_3_space_coordinates[2][0] += x_val
        _unrotated_3_space_coordinates[2][1] -= y_val

        _unrotated_3_space_coordinates[3][0] -= x_val
        _unrotated_3_space_coordinates[3][1] -= y_val

        #Step 5 - Return the unrotated 3-space euclidean coordinates
        return _unrotated_3_space_coordinates.transpose()

    def get_normalized_euclidean_image_plane_coordinates(self,K,RT_Mat,_homogeneous_world_coordinates):
        #This function will take in the RT_Mat calculate the remaining values in this class that can't be filled in until an RT_Mat is provided
        self._homogeneous_image_plane_coordinates = np.matmul(K,np.matmul(RT_Mat,_homogeneous_world_coordinates))
        self._euclidean_image_plane_coordinates = self.make_euclidean(self._homogeneous_image_plane_coordinates)
        self._T_matrix = self.calculate_T_matrix(self._euclidean_image_plane_coordinates)
        self._normalized_homogeneous_image_plane_coordinates = np.matmul(self._T_matrix,self._homogeneous_image_plane_coordinates)
        self._normalized_euclidean_image_plane_coordinates = self.make_euclidean(self._normalized_homogeneous_image_plane_coordinates)
        self._T_matrix_inverse = np.linalg.inv(self._T_matrix)
    '''IMAGE POINTS'''
    def _get_euclidean_corner_locations(self,image):
        #.shape gives height/rows/y first, then width/columns/x
        #We need it in x,y
        bottom_right = np.array((image.shape[1],image.shape[0]),dtype = 'float64')
        top_right = np.array([image.shape[1], 0.],dtype = 'float64')
        top_left = np.array([0.,0.],dtype = 'float64')
        bottom_left = np.array([0. ,image.shape[0]],dtype = 'float64')
        #starts at top_right and goes clockwise
        return (np.array([top_left,top_right,bottom_right,bottom_left])).transpose()

def combine_images():
    pass

def dominate_images():
    pass

def get_orientation(pose, rot_around_x = np.array([0,1,0]), rot_around_y = np.array([1,0,0]),rot_around_z = np.array([0,0,1]),print_angles=False):
    r_mat = quat2mat(pose)
    adjusted_rot_around_x = np.matmul(r_mat,rot_around_x)
    adjusted_rot_around_y = np.matmul(r_mat,rot_around_y)
    adjusted_rot_around_z = np.matmul(r_mat,rot_around_z)
    angles = np.array([degrees(acos(adjusted_rot_around_y[0])),
                       degrees(acos(adjusted_rot_around_x[1]))])
    if print_angles:
        print(angles)
    return adjusted_rot_around_y[2], adjusted_rot_around_z[2], angles

def check_orientation(pose):
    left_right, front_back, angles = get_orientation(pose)

    condition_index = "blank_pic"
    if ((angles[0] < 40) and (angles[1] < 40)): #angles[0] is for left right // angles[1] is for up down
        # print("Front")
        condition_index = "Front"
    if ((angles[0] > 140) and (angles[1] < 40)):
        # print("Back")
        condition_index = "Back"
    if ((((angles[0] > 50) and angles[0] < 130) and (angles[1] < 40)) and left_right >=0):
        # print("Right")
        condition_index = "Right"
    if ((((angles[0] > 50) and angles[0] < 130) and (angles[1] < 40)) and left_right < 0):
        # print("Left")
        condition_index = "Left"
    
    return condition_index

if __name__ == "__main__":

    #Call Eion's Fucntion here
    #aprilTag_initial_translation = np.array([0,0,0],dtype="float64"), aprilTag_initial_rotation = Eions_function(cfg)
    #
    #######################################
    pipe.stop()
    # Declare RealSense pipeline, encapsulating the actual device and sensors
    pipe = rs.pipeline()

    # Build config object and stream everything
    cfg = rs.config()
    #######################################

    aprilTag_initial_rotation = np.array([[1.,0.,0.],
                                          [0.,1.,0.],
                                          [0.,0.,1.]],dtype="float64")
    aprilTag_initial_translation = np.array([0,0,0],dtype="float64")

    aprilTag_initial_rotation, aprilTag_initial_translation = apriltag_detector.get_apriltag(cfg)
    print(aprilTag_initial_rotation.shape)
    # aprilTag_initial_rotation = np.matmul(euler2mat(0,radians(90),0), aprilTag_initial_rotation.reshape(3,3))

    tag = AprilTag(translation = aprilTag_initial_translation,rotation = aprilTag_initial_rotation)
    
    # complex_model = ProjectedImages(np.array([0,0,1],dtype='float64'),1,-90,"complex_model.jpg")
    complex_model = ProjectedImages(tag.translation,tag.rotation,np.array([0.5,0.,1.]),1,-90,"complex_model.jpg")
    ai4ce_logo = ProjectedImages(tag.translation,tag.rotation,np.array([0.,0.,1.]),1,0,"ai4ce_logo.png")
    front_room2 = ProjectedImages(tag.translation,tag.rotation,np.array([0.,1.,1.]),1,180,"front_room2.jpg")
    pipe_model = ProjectedImages(tag.translation,tag.rotation,np.array([3.,3.,1.]),2,0,"pipe_model.jpg")

    pic_list = [complex_model,ai4ce_logo,front_room2,pipe_model]

    position = np.array([0.,0.,-1.])
    orientation = np.array([1.,0.,0.,0.])
    K = np.array([[1,0,0],
                  [0,1,0],
                  [0,0,1]])
    camera = Camera(K=K)
    i = 1

    pipe = rs.pipeline()
    cfg = rs.config()
    cfg.enable_stream(rs.stream.pose)
    pipe.start(cfg)

    while(True):

        frames = pipe.wait_for_frames()
        pose = frames.get_pose_frame()
        data = pose.get_pose_data()

        x = data.translation.x
        y = data.translation.y
        z = data.translation.z
        V = np.array([-x,y,-z])
        

        quat = [data.rotation.w,-1*data.rotation.x,1*data.rotation.y,1*data.rotation.z]
        quat = qmult(quat,np.array([0.,0.,0.,1.]))
        # quat = qmult(quat, qinverse(tag.rotation) ) ##This should be replaced by applying a rotation and translation to the world coordinates
        # quat_prime = [data.rotation.w,1*data.rotation.x,-1*data.rotation.y,-1*data.rotation.z] ##This should be qconguate(quat)

        camera.extrinsics._projector_position = V
        camera.extrinsics._projector_orientation_quat = quat
        camera.extrinsics._projector_orientation_mat = camera.extrinsics.calculate_R_mat()
        camera.extrinsics.RT_mat = camera.extrinsics.calculate_RT_mat()
        i+=1
        for pic in pic_list:
            pic.get_normalized_euclidean_image_plane_coordinates(camera.intrinsics.K,camera.extrinsics.RT_mat,pic._homogeneous_world_coordinates)
            pic.get_warped_image()
        
        ##THIS IS HOW TO PUT IMAGES IN FRONT OF EACH OTHER
        front_image = front_room2.warped_image
        back_image = complex_model.warped_image
        ret, mask = cv2.threshold(front_image,1,255,cv2.THRESH_BINARY_INV)
        back_image = cv2.bitwise_or(back_image,front_image,mask = mask)
        # test =  back_image
        # test = front_image 
        test = front_image + back_image

        cv2.imshow('Original',front_room2.image)
        cv2.imshow('Projecter',test)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break


