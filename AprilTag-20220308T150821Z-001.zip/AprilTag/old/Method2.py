import os
import sys
import numpy as np
import cv2
from transforms3d.euler import euler2mat, mat2euler, quat2euler
from transforms3d.quaternions import quat2mat
from transforms3d.quaternions import qinverse
from transforms3d.quaternions import qconjugate
import math
import pyrealsense2 as rs
import random
from math import asin
from math import acos
from math import degrees
from math import radians

'''

ALGORITHM IDEAS

Using the K[R|t], we can figure out where the images should appear on a 2d image plane

Then we can find the homography between the opencv images after they have been scaled down and translated to the centroid and the images as they should appear on a projection plane

The points of the opencv images are the point locations after they have been transformed down

The points of the 

'''


### PyRealSense Stuff goes here:
pipe = rs.pipeline()
cfg = rs.config()
cfg.enable_stream(rs.stream.pose)
pipe.start(cfg)
###End of PyRealSense Stuff

class Camera:
    def  __init__(self,position=np.array([0.,0.,0.]),orientation=np.array([1.,0.,0.,0.]),K=np.eye(3,dtype='float64'),dist_coeffs = np.array([0.0,0.0])):
        self.intrinsics = self.Intrinsics(K,dist_coeffs)
        self.extrinsics = self.Extrinsics(position,orientation)
        
    class Intrinsics:
        def __init__(self,K,dist_coeffs):
            self.K = K
            self.dist_coeffs = dist_coeffs
    
    class Extrinsics:
        def __init__(self,position,orientation):
            self._projector_position = position
            self._projector_orientation_quat = orientation
            self._projector_orientation_mat = self.calculate_R_mat()
            self.RT_mat = self.calculate_RT_mat()

        def calculate_R_mat(self):
            return quat2mat(self._projector_orientation_quat)

        def calculate_RT_mat(self):
            return np.column_stack((self._projector_orientation_mat,self._projector_position))

    
class ProjectedImages:
    def __init__(self,position,size,orientation,file_name):
        self.size = size #WorldPoint
        self.initial_euclidean_image_position = self._get_corner_projection_location(self.size,position) #WorldPoint
        self.initial_homogeneous_image_position = self.make_homogeneous_corners(self.initial_euclidean_image_position) #WorldPoint
        self.initial_image_orientation = euler2mat(0,radians(orientation),0) #WorldPoint
        self.file_name = file_name
        self.transform = None
        self.homography = None
        self.image = self.get_picture()
        self.warped_image = None
        self.T_matrix_world = None #WorldPoints
        self.T_matrix = self._transform_down(self.image.shape[1],self.image.shape[0])
        self.T_matrix_prime = self._transform_up(final_width = 640,final_height = 480)
        self.calculate_homography = True
        self.camera_R = np.eye(3, dtype='float64')
        self.camera_T = np.eye(3, dtype='float64')
        self.corner_locations = self._get_corner_locations(self.image)
        self.homogeneous_corner_locations = self.make_homogeneous_corners(self.corner_locations)
        self.normalized_corner_locations = self.normalize_corner_locations()

    class WorldPoints:
        def __init__(self):
            self.initial_image_orientation = None #Tells us how to rotate
            self.position = None #Tells us where the center is
            self.size = None #Tells us how big it is
            self._euclidean_world_coordinates = None #We calculate this to figure out where the corners should be in euclidean 3-space
            self._homogeneous_world_coordinates = None #This is based on the self._euclidean_world_coordinates, simply make these coordinates homogenous
            self._homogeneous_image_plane_coordinates = None #This is the self._homogeneous_world_coordinates projected onto the 2D image plane
            self._T_matrix = None #This is the matrix to normalize the homogeneous coordinates
            self._normalized_homogeneous_image_plane_coordinates = None #This is the normalized self._homogeneous_image_plane_coordinates
            self._normalized_euclidean_image_plane_coordinates = None #This is based on the self._normalized_homogeneous_image_plane_coordinates, simply make these coordinates euclidean
            self._T_matrix_inverse = None #This is needed to calculate the correct homography
            
            self.initial_euclidean_image_position = None
            self.initial_homogeneous_image_position = None
            
            self.T_matrix_world = None
            pass
    
    class ImagePoints:
        def __init__(self):
            self.euclidean_corner_locations = None #This tells us where the corner locations are for an opencv image
            self.homogeneous_corner_locations = None #This is based on the self.corner_locations, simple make these coordinates homogeneous
            self.T_matrix = None #This is the matrix to normalize the homogeneous coordinates
            self.normalized_homogeneous_corner_locations = None #This is the normalized self.homogeneous_corner_locations
            self.normalized_euclidean_corner_locations = None #This is based on the self.normalized_homogeneous_corner_locations, simply make these coordinates euclidean
            self.T_matrix_inverse = None #This is needed to calculate the correct homography

            pass


    def _get_corner_projection_location(self,size,center_position = np.array([0.0,0.0,0.0])):
        #size is in meters
        #center_position has x,y,z
        _dist = size/2
        _xi = center_position[0]
        _yi = center_position[1]
        _zi = center_position[2]
        top_left = np.array([-_dist+_xi,_dist+_yi,0.0+_zi])
        top_right = np.array([_dist+_xi,_dist+_yi,0.0+_zi])
        bottom_left = np.array([-_dist+_xi,-_dist+_yi,0.0+_zi])
        bottom_right = np.array([_dist+_xi,-_dist+_yi,0.0+_zi])
        return np.array([top_left,top_right,bottom_right,bottom_left])

    def _get_corner_locations(self,position):
        #.shape gives height/rows/y first, then width/columns/x
        #We need it in x,y
        bottom_right = np.array((position.shape[1],position.shape[0]),dtype = 'float64')
        top_right = np.array([position.shape[1], 0.],dtype = 'float64')
        top_left = np.array([0.,0.],dtype = 'float64')
        bottom_left = np.array([0. ,position.shape[0]],dtype = 'float64')
        #starts at top_right and goes clockwise
        return np.array([top_left,top_right,bottom_right,bottom_left])
    
    def normalize_corner_locations(self):
        holding_list = []
        for point in self.homogeneous_corner_locations:
            holding_coord= np.matmul(self.T_matrix,point)
            holding_coord = holding_coord/holding_coord[-1]
            holding_list.append(holding_coord)
        return np.array(holding_list)
        
    def make_homogeneous_corners(self,corners):
        ones_vector = np.ones(corners.shape[0])
        return np.column_stack((corners,ones_vector))

    def make_homogeneous(self,euclidean_vector):
        homogeneous_vector = np.append(euclidean_vector,1.)
        return homogeneous_vector

    def _transform_down(self, initial_width = 640,initial_height = 480):
        ##First, need to move the picture to the centroid
        T_cent_mat_initial = np.eye(3, dtype='float64')
        T_cent_mat_initial[0, 2] = -initial_height / 2
        T_cent_mat_initial[1, 2] = -initial_width / 2
        ##Then we need to scale down, we will scale up by the same amount
        ave_dist_to_initial_centroid = math.sqrt((initial_width/2)**2+(initial_height/2)**2)
        S_down_mat = np.eye(3, dtype='float64')
        S_down_mat[0, 0] = math.sqrt(2) / ave_dist_to_initial_centroid
        S_down_mat[1, 1] = math.sqrt(2) / ave_dist_to_initial_centroid

        T_matrix = np.matmul(S_down_mat,T_cent_mat_initial)
        ##Then we apply the transformation
        ###THIS IS DONE INSIDE THE WHILE LOOP
        return T_matrix
    
    def _transform_up(self, scale_factor = 1,final_width = 640,final_height = 480):
        ##Then we scale back up, we scale up by the same amount we scaled down
        ave_dist_to_final_centroid = math.sqrt((final_width/2)**2+(final_height/2)**2)
        S_up_mat = np.eye(3, dtype='float64')
        
        S_up_mat[0, 0] = (math.sqrt(2) / (ave_dist_to_final_centroid*2))*scale_factor
        S_up_mat[1, 1] = (math.sqrt(2) / (ave_dist_to_final_centroid*2))*scale_factor

        ##Then we need the move the transformation back to the center of the screen
        T_cent_mat_final = np.eye(3, dtype=int)
        T_cent_mat_final[0, 2] = -(final_height / 2)
        T_cent_mat_final[1, 2] = -(final_width / 2)


        T_matrix_prime = np.matmul(S_up_mat,T_cent_mat_final)

        return T_matrix_prime

    '''TO CALCULATE THE NORMALIZED LOCATION'''
    def normalization_matrix(self,image_points):
        required_tranlation_distance = self._calculate_image_centroid_location(image_points)
        centered_image_points = self._center_points_around_origin(image_points, required_tranlation_distance)
        scale_factor = self._find_average_distance_from_centroid(centered_image_points)
        S_down_mat = np.eye(3, dtype='float64')
        S_down_mat[0, 0] = (math.sqrt(2) / (scale_factor*2))
        S_down_mat[1, 1] = (math.sqrt(2) / (scale_factor*2))
        
        T_cent_mat = np.eye(3, dtype=int)
        T_cent_mat[0, 2] = -(required_tranlation_distance[1] / 2)
        T_cent_mat[1, 2] = -(required_tranlation_distance[0] / 2)

        return np.matmul(S_down_mat,T_cent_mat)


    def _calculate_image_centroid_location(self,image_points):
        
        x_ave_y_ave = image_points.sum(axis=0)
        return x_ave_y_ave/4

        '''DELETE IF THE ABOVE WORKS'''
        # x_ave_image = 0.0
        # y_ave_image = 0.0

        # for i in range(4):
        #     x_ave_image += image_points[i][0]
        #     y_ave_image += image_points[i][1]

        # x_ave_image= x_ave_image/4
        # y_ave_image= y_ave_image/4

        # return np.array([x_ave_image,y_ave_image])
        '''DELETE IF THE ABOVE WORKS'''

    def _center_points_around_origin(self, original_points,original_points_centroid_dist_to_origin):
        return original_points - original_points_centroid_dist_to_origin

    def _find_average_distance_from_centroid(self,centered_original_points):
        
        distances_to_centroid = np.linalg.norm(centered_original_points,axis =1)
        summed_distances_of_points_to_centroid = distances_to_centroid.sum(axis=0)
        return summed_distances_of_points_to_centroid/4

        '''DELETE IF THE ABOVE WORKS'''
        # #Points don't actually have to be centered, but centerring them is part of the algorithm
        # summed_distances_of_points_to_centroid = 0
        # #Below we calculate the average distance of each point from the centroid
        # for i in range(4):
        #     summed_distances_of_points_to_centroid += np.linalg.norm(centered_original_points[i],2)
        # return summed_distances_of_points_to_centroid/4
        '''DELETE IF THE ABOVE WORKS'''
    

    '''END OF SECTION TO CALCULATE THE NORMALIZED LOCATION'''
        
    def get_picture(self):
        frame = cv2.imread(self.file_name)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        return gray


def make_euclidean_2_space_matrix(homogeneous_points_matrix):
    holding_list = []
    for homogeneous_vector in np.transpose(homogeneous_points_matrix):
        holding_list.append(make_euclidean_2_space_vector(homogeneous_vector))
    return np.array(holding_list)

def make_euclidean_2_space_vector(homogeneous_vector):
    euclidean_vector = homogeneous_vector/homogeneous_vector[-1]
    euclidean_vector = np.array([euclidean_vector[0],euclidean_vector[1]])
    return euclidean_vector

if __name__ == "__main__":
    # complex_model = ProjectedImages(np.array([0,0,1],dtype='float64'),1,-90,"complex_model.jpg")
    _complex_model = ProjectedImages(np.array([0.,0.,1.]),1,-90,"complex_model.jpg")
    ai4ce_logo = ProjectedImages(np.array([0.,0.,1.]),1,0,"ai4ce_logo.png")
    front_room2 = ProjectedImages(np.array([3.,3.,1.]),1,0,"front_room2.jpg")
    pipe_model = ProjectedImages(np.array([0.,0.,1.]),1,0,"pipe_model.jpg")

    pic_list = [_complex_model,ai4ce_logo,front_room2,pipe_model]

    position = np.array([0.,0.,-1.])
    orientation = np.array([1.,0.,0.,0.])
    K = np.array([[10,0,0],
                  [0,10,0],
                  [0,0,1]])
    camera = Camera(K=K)
    i = 1
    while(True):
        # print(complex_model.normalized_corner_locations)
        camera.extrinsics._projector_position = position
        camera.extrinsics._projector_orientation_quat = orientation
        camera.extrinsics._projector_orientation_mat = camera.extrinsics.calculate_R_mat()
        camera.extrinsics.RT_mat = camera.extrinsics.calculate_RT_mat()
        i+=1
        # print(i)
        # print(front_room2.initial_homogeneous_image_position)
        print("\n")
        for pic in pic_list:
            image_plane_homogeneous_points = np.matmul(K, np.matmul(camera.extrinsics.RT_mat,np.transpose(pic.initial_homogeneous_image_position)))
            image_plane_euclidean_points = make_euclidean_2_space_matrix(image_plane_homogeneous_points)
            # h, status = cv2.findHomography(pts_src, pts_dst)
            # print(camera.intrinsics.K)
            # print(pic.initial_euclidean_image_position)
            # print(pic.initial_homogeneous_image_position)
            # print(image_plane_homogeneous_points)
            # print(transformed_points)
            pic.T_matrix_world = pic.normalization_matrix(image_plane_euclidean_points)
            print(pic.normalization_matrix(image_plane_euclidean_points))
            # cv2.findHomography(pic.)
            print("--------")
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break