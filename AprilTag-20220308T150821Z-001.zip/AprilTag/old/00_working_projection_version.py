import os
import sys
import numpy as np
import cv2
from transforms3d.euler import euler2mat, mat2euler, quat2euler
from transforms3d.quaternions import quat2mat, mat2quat
from transforms3d.quaternions import qinverse
from transforms3d.quaternions import qconjugate
import math
import pyrealsense2 as rs
import random
from math import asin
from math import acos
from math import degrees
from math import radians

### PyRealSense Stuff goes here:
pipe = rs.pipeline()
cfg = rs.config()
cfg.enable_stream(rs.stream.pose)
pipe.start(cfg)
###End of PyRealSense Stuff

def display_window(name,final_width = 640,final_height = 480):
    cv2.namedWindow(name, cv2.WINDOW_KEEPRATIO)
    cv2.resizeWindow(name, final_width, final_height)

def hamilton_product(_1, _2):
    a1, b1, c1, d1 = _1
    a2, b2, c2, d2 = _2

    w = a1*a2 - b1*b2 - c1*c2 - d1*d2
    i = a1*b2 + b1*a2 + c1*d2 - d1*c2
    j = a1*c2 - b1*d2 + c1*a2 + d1*b2
    k = a1*d2 + b1*c2 - c1*b2 + d1*a2

    return [w,i,j,k]

def get_orientation(pose, rot_around_x = np.array([0,1,0]), rot_around_y = np.array([1,0,0]),rot_around_z = np.array([0,0,1]),print_angles=False):
    adjusted_rot_around_x = np.matmul(pose,rot_around_x)
    adjusted_rot_around_y = np.matmul(pose,rot_around_y)
    adjusted_rot_around_z = np.matmul(pose,rot_around_z)
    angles = np.array([degrees(acos(adjusted_rot_around_y[0])),
                       degrees(acos(adjusted_rot_around_x[1]))])
    if print_angles:
        print(angles)
    return adjusted_rot_around_y[2], adjusted_rot_around_z[2], angles

def check_orientation(pose):
    left_right, front_back, angles = get_orientation(pose)

    condition_index = "blank_pic"
    if ((angles[0] < 40) and (angles[1] < 40)): #angles[0] is for left right // angles[1] is for up down
        # print("Front")
        condition_index = "Front"
    if ((angles[0] > 140) and (angles[1] < 40)):
        # print("Back")
        condition_index = "Back"
    if ((((angles[0] > 50) and angles[0] < 130) and (angles[1] < 40)) and left_right >=0):
        # print("Right")
        condition_index = "Right"
    if ((((angles[0] > 50) and angles[0] < 130) and (angles[1] < 40)) and left_right < 0):
        # print("Left")
        condition_index = "Left"
    
    return condition_index

class ProjectedImages:
    def __init__(self,position,orientation,file_name):
        self.initial_position = position
        self.initial_orientation = euler2mat(0,radians(orientation),0)
        self.file_name = file_name
        self.transform = None
        self.homography = None
        self.image = self.get_picture()
        self.warped_image = None
        self.T_matrix = self._transform_down(self.image.shape[1],self.image.shape[0])
        self.T_matrix_prime = self._transform_up(final_width = 640,final_height = 480)
        self.calculate_homography = True
        self.camera_R = np.eye(3, dtype=float)
        self.camera_T = np.eye(3, dtype=float)

    def _scale_away(self):
        #First we want to move this picture to the 0,0,0
            #Not sure where the picture is

        #Then we want to scale it to that the distance that is is from the 0,0,0 is multiplied by 2

        #Then we want to move the picture back to the original position
        pass


    def _transform_down(self, initial_width = 640,initial_height = 480):
        ##First, need to move the picture to the centroid
        T_cent_mat_initial = np.eye(3, dtype=float)
        T_cent_mat_initial[0, 2] = -initial_height / 2
        T_cent_mat_initial[1, 2] = -initial_width / 2
        ##Then we need to scale down, we will scale up by the same amount
        ave_dist_to_initial_centroid = math.sqrt((initial_width/2)**2+(initial_height/2)**2)
        S_down_mat = np.eye(3, dtype=float)
        S_down_mat[0, 0] = math.sqrt(2) / ave_dist_to_initial_centroid
        S_down_mat[1, 1] = math.sqrt(2) / ave_dist_to_initial_centroid

        T_matrix = np.matmul(S_down_mat,T_cent_mat_initial)
        ##Then we apply the transformation
        ###THIS IS DONE INSIDE THE WHILE LOOP
        return T_matrix
    
    def _transform_up(self, scale_factor = 1,final_width = 640,final_height = 480):
        ##Then we scale back up, we scale up by the same amount we scaled down
        ave_dist_to_final_centroid = math.sqrt((final_width/2)**2+(final_height/2)**2)
        S_up_mat = np.eye(3, dtype=float)
        
        S_up_mat[0, 0] = (math.sqrt(2) / (ave_dist_to_final_centroid*2))*scale_factor
        S_up_mat[1, 1] = (math.sqrt(2) / (ave_dist_to_final_centroid*2))*scale_factor

        ##Then we need the move the transformation back to the center of the screen
        T_cent_mat_final = np.eye(3, dtype=int)
        T_cent_mat_final[0, 2] = -(final_height / 2)
        T_cent_mat_final[1, 2] = -(final_width / 2)


        T_matrix_prime = np.matmul(S_up_mat,T_cent_mat_final)

        return T_matrix_prime
    
    def get_picture(self):
        frame = cv2.imread(self.file_name)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        return gray

display_window('Projecter')
display_window('Original')
# display_window('Combined')

#FOR TESTING - Choose a condition and display only that image
condition_list = [1,2,3,4]
condition = random.choice(condition_list)

complex_model = ProjectedImages([0,0,1],-90,"complex_model.jpg")
ai4ce_logo = ProjectedImages([0,0,0],0,"ai4ce_logo.png")
front_room2 = ProjectedImages([0,0,0],0,"front_room2.jpg")
pipe_model = ProjectedImages([0,0,1],0,"pipe_model.jpg")

final_width = 640
final_height = 480

pic_list = [complex_model,ai4ce_logo,front_room2,pipe_model]
i = 0
while(True):
    #Boilerplate code to get info from T265
    frames = pipe.wait_for_frames()
    pose = frames.get_pose_frame()
    data = pose.get_pose_data()

    quat = [data.rotation.w,-1*data.rotation.x,1*data.rotation.y,1*data.rotation.z]
    quat_prime = [data.rotation.w,1*data.rotation.x,-1*data.rotation.y,-1*data.rotation.z]
    R=quat2mat(quat)
    # print(check_orientation(R))

    x = data.translation.x
    y = data.translation.y
    z = data.translation.z
    P = [0,x,y,z]

    P_prime = P
    P_prime = hamilton_product( hamilton_product(quat_prime,P) , quat)
    # print(P_prime)

    for pic in pic_list:

        # pic.camera_R = np.matmul(R,pic.initial_orientation)
        # pic.camera_T[2, 0] = pic.initial_position[0] - P_prime[1]
        # pic.camera_T[2, 1] = pic.initial_position[1] + P_prime[2]
        # pic.camera_T[2, 2] = pic.initial_position[2] + P_prime[3]
        # #pic.camera_T = np.matmul(pic.camera_T,pic.initial_position)
        '''TRY THE FOLLOWING'''
        #Rotate to initial orientation
        initial_orientation = pic.initial_orientation
        quat_int_orient = mat2quat(initial_orientation)
        quat_int_orient_conj = qconjugate(quat_int_orient)
        P2_prime = hamilton_product( hamilton_product(quat_int_orient_conj,P) , quat_int_orient)
        holder = [0,pic.initial_position[0],pic.initial_position[1],pic.initial_position[2]]
        holder_prime = hamilton_product( hamilton_product(quat_int_orient_conj,holder) , quat_int_orient)
        initial_position = np.eye(3,dtype=float)
        initial_position[2,0]+=holder[1]
        initial_position[2,1]+=holder[2]
        initial_position[2,2]+=holder[3]
        # np.array([[1,0,0+pic.initial_position[0]],
        #                              [0,1,0+pic.initial_position[1]],
        #                              [0,0,1+pic.initial_position[2]]],dtype=float)

        
        trans_based_on_camera = np.eye(3,dtype=float)
        trans_based_on_camera[2,0]-=P_prime[1]
        trans_based_on_camera[2,1]+=P_prime[2]
        trans_based_on_camera[2,2]+=P_prime[3]
        # trans_based_on_camera = np.array([[1,0,0+P_prime[1]],
        #                                   [0,1,0+P_prime[2]],
        #                                   [0,0,1+P_prime[3]]],dtype=float)
        
        rot_based_on_camera = R
        step1 = np.matmul(initial_position,initial_orientation)
        step2 = np.matmul(trans_based_on_camera,step1)
        step3 = np.matmul(R,step2)
        pic.transform = step3
        print(pic.transform)
        # print(step3.shape)
        # print(pic.T_matrix_prime.shape)
        print(pic.T_matrix)
        # print(np.linalg.inv(pic.T_matrix_prime).shape)
        #Translate to initial position
        #Translate based on camera position
        #Rotate based on camera orientation
        '''END OF TRIAL'''

        # pic.transform = np.matmul(pic.camera_T, pic.camera_R)
        pic.homography = np.matmul(pic.transform,pic.T_matrix)
        pic.homography = np.matmul(np.linalg.inv(pic.T_matrix_prime),pic.homography)
        pic.warped_image = cv2.warpPerspective(pic.image, pic.homography, (final_width, final_height))
    
    ###BASED ON AN ORIENTATION, I NEED TO SHOW A SPECIFIC IMAGE###

    test = complex_model.warped_image + pipe_model.warped_image

    cv2.imshow('Original',complex_model.image)
    cv2.imshow('Projecter',test)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
cv2.destroyAllWindows()